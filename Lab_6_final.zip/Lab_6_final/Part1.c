#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// goal: reading numbers from a file and combining them sequentially using a function f


// the function takes as parameters the file and a pointer to a function(f) which takes two long long values and returns a long long as well
// this function returns the final aggregated value
long long sequential_compute(const char *filepath,long long (*f)(long long, long long)) 
{
    FILE *file = fopen(filepath, "r");
    if (file == NULL) 
    {
        perror("fopen");
        return 0; //returning 0 if it fails to open 
    }

    long long count = 0; // number of values read so far
    long long result = 0;
    char line[1024]; // temporary buffer that reads one line at a time


    // looping line by line as long as we havent reached the end (one number per line)
    // each value is combined into result right away, so no array is needed
    while (fgets(line, sizeof(line), file) != NULL) {
        long long read_val = atoll(line);
        result = (count == 0) ? read_val : f(result, read_val);
        count++;
    }


    // close the file
    fclose(file);
    return result; // 0 if the file was empty
}

/*
Example usage:

long long add(long long a, long long b) {
    return a + b;
}

int main(void) {
    long long result = sequential_compute("numbers.txt", add);
    printf("Result = %lld\n", result);
    return 0;
}
*/