
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

// the functions in part 1 and part 2
long long sequential_compute(const char *filepath,long long (*f)(long long, long long));

long long parallel_compute(char *filename,int n_proc,long long (*f)(long long, long long));


// benchmarks
#define INPUT_FILE "numbers.txt"
#ifndef POINTS
#define POINTS 50  //number of different input sizes (log spaced)
#endif
#define MAX_REPETITIONS 21 // the most repetitions any N gets
#define FIXED_PROCESSES 10 // fixing n_proc to 10 (number of performance cores on the M4 Pro)
#define MIN_N 1000LL
#ifndef MAX_N
#define MAX_N 8000000000LL // can be overridden with -DMAX_N=... for a quick test
#endif

// small N runs are fast but noisy so they get more repetitions,
// large N runs are slow but stable so they get fewer (always odd for a clean median)
int repetitions_for(long long N)
{
    if (N < 100000000LL) return 21;
    if (N <= 1000000000LL) return 11;
    return 5;
}

// comparing doubles for qsort
int compare_doubles(const void *a, const void *b)
{
    double x = *(const double *)a;
    double y = *(const double *)b;
    return (x > y) - (x < y);
}

// median of the first n values (sorts the array in place)
double median(double *values, int n)
{
    qsort(values, n, sizeof(double), compare_doubles);
    return (n % 2 == 1) ? values[n / 2] : (values[n / 2 - 1] + values[n / 2]) / 2.0;
}

// the aggregate function to test
long long add(long long a, long long b)
{
    return a + b;
}

// calculating the elapsed time in seconds
double elapsed_seconds(struct timespec start, struct timespec end)
{
    // converting the difference in seconds and nanoseconds into seconds
    return (double)(end.tv_sec - start.tv_sec)+ (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

// generating an input file containing N 1's 
int generate_input(long long N)
{
    // opening the input file in write mode, replacing its 
    FILE *file = fopen(INPUT_FILE, "w");

    // stop if the file cannot be opened
    if (file == NULL) {
        perror("Opening input file");
        return -1;
    }
    //writing N numbers to the file in big chunks (fprintf per line is too slow for N = 8e9)
    static char chunk[1 << 20];
    const long long lines_per_chunk = sizeof(chunk) / 2;
    for (long long i = 0; i < lines_per_chunk; i++) {
        chunk[2 * i] = '1';
        chunk[2 * i + 1] = '\n';
    }
    for (long long written = 0; written < N; written += lines_per_chunk) {
        long long lines = (N - written < lines_per_chunk) ? N - written : lines_per_chunk;
        if (fwrite(chunk, 2, (size_t)lines, file) != (size_t)lines) {
            perror("Writing input file");
            fclose(file);
            return -1;
        }
    }
    //close the file 
    if (fclose(file) != 0) {
        perror("Closing input file");
        return -1;
    }
    return 0;
}

//function to verify that both functions are returning the same number 
int verify_results(long long N)
{
    long long sequential = sequential_compute(INPUT_FILE, add);

    long long parallel = parallel_compute((char *)INPUT_FILE,FIXED_PROCESSES, add); 

    // The sum is supposed to be N so we check whether they both return N
    if (sequential != N || parallel != N) 
    {
        fprintf(stderr,"ERROR: N=%lld, sequential=%lld, parallel=%lld\n",N, sequential, parallel);
        return 0; // if either one or both are wrong
    }

    return 1;
}

// measuring the execution time of the sequential
double time_sequential(void)
{
    struct timespec start, end;
    // recording the start time 
    clock_gettime(CLOCK_MONOTONIC, &start);
    // run the function
    long long result = sequential_compute(INPUT_FILE, add);
    // recording the end time
    clock_gettime(CLOCK_MONOTONIC, &end);
    (void)result;

    // use our function to get the time in secondd
    return elapsed_seconds(start, end);
}

// measuring the execution time of the parallel
double time_parallel(void)
{
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    long long result = parallel_compute((char *)INPUT_FILE,FIXED_PROCESSES,add);
    clock_gettime(CLOCK_MONOTONIC, &end);

    (void)result;

    return elapsed_seconds(start, end);
}

int main(void)
{
    // raw CSV: every single reading
    FILE *out = fopen("part3_1_raw.csv", "w");
    // median CSV: one row per N (used to build the Excel sheet)
    FILE *medians = fopen("part3_1_median.csv", "w");

    if (out == NULL || medians == NULL) {
        perror("Opening results CSV");
        return 1;
    }

    //printing the headers
    if (fprintf(out, "N,n_proc,repetition,sequential_seconds,parallel_seconds\n") < 0 ||
        fprintf(medians, "N,n_proc,repetitions,sequential_median_seconds,parallel_median_seconds\n") < 0)
    {
        perror("Writing CSV header");
        return 1;
    }

    // ensuring the header is written before the computation
    if (fflush(out) != 0 || fflush(medians) != 0) {
        perror("Flushing CSV header");
        return 1;
    }

    //displaying the benchmarks
    printf("Part 3 (1): fixed n_proc = %d\n", FIXED_PROCESSES);
    printf("N range: %lld to %lld (log spaced)\n", MIN_N, MAX_N);
    printf("Input sizes: %d\n", POINTS);
    printf("Repetitions per size: 21 (N < 1e8), 11 (1e8 <= N <= 1e9), 5 (N > 1e9)\n");
    fflush(stdout);

    long long previous_N = 0;

    // testing POINTS different input sizes from MIN_N to MAX_N
    for (int point = 0; point < POINTS; point++)
    {
        //calculating the current input size
        //distributing the points evenly on a log scale so the small N crossover region gets points too
        long long N = llround((double)MIN_N * pow((double)MAX_N / MIN_N, (double)point / (POINTS - 1)));
        if (N <= previous_N) N = previous_N + 1; // keep N strictly increasing
        previous_N = N;
        int repetitions = repetitions_for(N);

        // generating the input file
        if (generate_input(N) != 0) {
            return 1;
        }

        // verifying correctness before we start (this also warms up the page cache, untimed)
        if (!verify_results(N)) {
            fprintf(stderr,
                    "Computation verification failed for N=%lld :((( \n", N);
            return 1;
        }
        printf("\n========================================\n");
        printf("Point %d/%d | N = %lld | n_proc = %d | repetitions = %d\n", point + 1, POINTS, N, FIXED_PROCESSES, repetitions);
        printf("========================================\n");

        double sequential_times[MAX_REPETITIONS];
        double parallel_times[MAX_REPETITIONS];

        for (int trial = 0; trial < repetitions; trial++) {
            double sequential_time;
            double parallel_time;

            // alternating the implementations: sequential -> parallel -> sequential ->parallel
            if (trial % 2 == 0) {
                sequential_time = time_sequential();
                parallel_time = time_parallel();
            } else {
                parallel_time = time_parallel();
                sequential_time = time_sequential();
            }

            // keeping the times to calculate the median
            sequential_times[trial] = sequential_time;
            parallel_times[trial] = parallel_time;

            // printing every repition
            printf("Repetition %2d | Sequential: %.9f s"" | Parallel: %.9f s\n",trial + 1,sequential_time,parallel_time);

            if (fprintf(out, "%lld,%d,%d,%.9f,%.9f\n",N,FIXED_PROCESSES,trial + 1,sequential_time,parallel_time) < 0)
            {
                perror("Writing measurement");
                return 1;
            }
            if (fflush(out) != 0)
            {
                perror("Flushing results CSV");
                return 1;
            }
            fflush(stdout);
        }

        // calculating the medians (smooths out the noisy readings)
        double sequential_median = median(sequential_times, repetitions);
        double parallel_median = median(parallel_times, repetitions);

        printf("----------------------------------------\n");
        printf("Median | Sequential: %.9f s"" | Parallel: %.9f s\n",sequential_median, parallel_median);

        // adding the median as a row in the median CSV
        if (fprintf(medians, "%lld,%d,%d,%.9f,%.9f\n",N, FIXED_PROCESSES, repetitions, sequential_median, parallel_median) < 0)
        {
            perror("Writing median");
            return 1;
        }
        fflush(medians);
    }

    if (fclose(out) != 0 || fclose(medians) != 0)
    {
        perror("Closing results CSV");
        return 1;
    }

    // the largest input file is ~16 GB, so we delete it at the end
    remove(INPUT_FILE);

    printf("\nTest 1 completed successfully :) \n");
    printf("Results have been saved to part3_1_raw.csv and part3_1_median.csv!!\n");
    return 0;
}
