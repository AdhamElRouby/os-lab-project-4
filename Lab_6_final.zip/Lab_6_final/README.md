# Lab 6 – Part 3: sequential_compute vs parallel_compute

## How the tests were designed

### Machine specs
- macOS
- 14 CPU cores: 10 performance cores + 4 efficiency cores
- The two experiments were run one after the other, never at the same time, so they never competed for the CPU and each one got the machine to itself.

### Ranges for each experiment
- **Experiment 1:** `n_proc` fixed at **10** (the number of performance cores). `N` varied over **50 values from 1,000 to 8,000,000,000**, evenly spaced on a log scale: each value is about **1.383×** the previous one.
- **Experiment 2:** `N` fixed at **1,000,000**. `n_proc` varied over **1, 2, 4, 6, …, 128** (65 values).

The input file is `N` lines, each containing `1`, and the aggregate function is `add`, so both functions must return `N`.

### Curve smoothing
Each point on the graphs is the **median** of several timed readings: the readings are sorted and the middle one is kept. Short runs are noisier, so they get more readings:

| Experiment | Range | Readings per point |
|---|---|---|
| 1 | N < 10⁸ | 21 |
| 1 | 10⁸ ≤ N ≤ 10⁹ | 11 |
| 1 | N > 10⁹ | 5 |
| 2 | every n_proc | 101 |

## Pseudocode for the experiments

**Experiment 1: fixed n_proc = 10, vary N**

```
FOR each N in [1000, 1383, 1912, ..., 8,000,000,000]   (50 values)

    reps ← 21 if N < 100,000,000
           11 if N ≤ 1,000,000,000
            5 otherwise

    CREATE file with N lines of "1"

    FOR round = 1 to reps
        IF round is odd
            seq_time ← TIME( sequential )
            par_time ← TIME( parallel with 10 processes )
        ELSE
            par_time ← TIME( parallel with 10 processes )
            seq_time ← TIME( sequential )
        SAVE (N, round, seq_time, par_time) to raw CSV

    SAVE (N, median of seq_times, median of par_times) as one graph point

DELETE file
```

**Experiment 2: fixed N = 1,000,000, vary n_proc**

```
CREATE file with 1,000,000 lines of "1"      // once only

FOR each n_proc in [1, 2, 4, 6, ..., 128]    (65 values)

    FOR round = 1 to 101
        IF round is odd
            seq_time ← TIME( sequential )
            par_time ← TIME( parallel with n_proc processes )
        ELSE
            par_time ← TIME( parallel with n_proc processes )
            seq_time ← TIME( sequential )
        SAVE (n_proc, round, seq_time, par_time) to raw CSV

    SAVE (n_proc, median of seq_times, median of par_times) as one graph point

DELETE file
```

**What TIME( f ) does:**

```
start ← clock
run f
end   ← clock
RETURN end − start
```

The order of the two functions swaps every round, so neither one always benefits (or suffers) from running second.

## Answers to the questions

1. **Fixed n_proc = 10:** parallel wins once **N ≈ 2.5 × 10⁵**. Sequential still wins at N = 179,502; parallel wins at N = 248,284 and at every larger N. At N = 8 × 10⁹, parallel is about 4.2× faster (36.5 s vs 154.3 s).
2. **Fixed N = 1,000,000:** parallel wins for **n_proc from 2 to 64**. With 1 process it is slower than sequential, and from 66 processes on the cost of forking outweighs the gain. The fastest is n_proc = 10 (7.7 ms vs 20.0 ms, about 2.6× faster).

## Files
- `Part1.c`, `Part2.c`: `sequential_compute` and `parallel_compute`
- `Part3_1.c`, `Part3_2.c`: the two experiments
- `part3_1_raw.csv`, `part3_2_raw.csv`: every individual reading
- `results.xlsx`: medians and graphs, one sheet per experiment
