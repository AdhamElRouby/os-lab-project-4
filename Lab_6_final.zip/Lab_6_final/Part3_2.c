
/* Enable POSIX functions, including clock_gettime() */
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

/* Functions implemented in Part1.c and Part2.c */
long long sequential_compute(
    const char *filepath,
    long long (*f)(long long, long long)
);

long long parallel_compute(
    char *filename,
    int n_proc,
    long long (*f)(long long, long long)
);


// benchmarks 

#define INPUT_FILE "numbers.txt"
#define FIXED_N 1000000LL     // keeping N constant (big enough to gain from parallelism, small enough that fork overhead shows)
#define MIN_PROCESSES 1       // Min processes is 1
#ifndef MAX_PROCESSES
#define MAX_PROCESSES 128     // testing until 128 processes
#endif
#ifndef PROCESS_STEP
#define PROCESS_STEP 2        // n_proc = 1, 2, 4, 6, ..., 128
#endif
#ifndef REPETITIONS
#define REPETITIONS 101       // repeating 101 times for each n_proc (odd for a clean median)
#endif

// the aggregate function to test
long long add(long long a, long long b)
{
    return a + b;
}

// calculating the elapsed time in seconds
double elapsed_seconds(struct timespec start, struct timespec end)
{
    return (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

// comparing doubles for qsort
int compare_doubles(const void *a, const void *b)
{
    double x = *(const double *)a;
    double y = *(const double *)b;
    return (x > y) - (x < y);
}

// median of the first n values (sorts the array in place)
double median(double *values, int n)
{
    qsort(values, n, sizeof(double), compare_doubles);
    return (n % 2 == 1) ? values[n / 2] : (values[n / 2 - 1] + values[n / 2]) / 2.0;
}

// generating an input file containing N 1's 
int generate_input(void)
{
    FILE *file = fopen(INPUT_FILE, "w");
    if (file == NULL) 
    {
        perror("Opening input file");
        return -1;
    }

    //writing N numbers to the file in big chunks
    static char chunk[1 << 20];
    const long long lines_per_chunk = sizeof(chunk) / 2;
    for (long long i = 0; i < lines_per_chunk; i++) {
        chunk[2 * i] = '1';
        chunk[2 * i + 1] = '\n';
    }
    for (long long written = 0; written < FIXED_N; written += lines_per_chunk) {
        long long lines = (FIXED_N - written < lines_per_chunk) ? FIXED_N - written : lines_per_chunk;
        if (fwrite(chunk, 2, (size_t)lines, file) != (size_t)lines) {
            perror("Writing input file");
            fclose(file);
            return -1;
        }
    }

    if (fclose(file) != 0) 
    {
        perror("Closing input file");
        return -1;
    }

    return 0;
}

//function to verify that both functions are returning the same number 
int verify_results(int n_proc)
{
    long long sequential = sequential_compute(INPUT_FILE, add);
    long long parallel = parallel_compute((char *)INPUT_FILE,n_proc,add);

    // The sum is supposed to be N so we check whether they both return N
    if (sequential != FIXED_N || parallel != FIXED_N) {
        fprintf(stderr,"ERROR: n_proc=%d, sequential=%lld, parallel=%lld\n",n_proc, sequential, parallel);
        return 0;
    }
    return 1;
}

// measuring the execution time of the sequential
double time_sequential(void)
{
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    long long result = sequential_compute(INPUT_FILE, add);
    clock_gettime(CLOCK_MONOTONIC, &end);
    (void)result;
    return elapsed_seconds(start, end);
}

// measuring the execution time of the parallel
double time_parallel(int n_proc)
{
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    long long result = parallel_compute((char *)INPUT_FILE, n_proc,add);
    clock_gettime(CLOCK_MONOTONIC, &end);
    (void)result;
    return elapsed_seconds(start, end);
}


int main(void)
{
    // raw CSV: every single reading
    FILE *out = fopen("part3_2_raw.csv", "w");
    // median CSV: one row per n_proc (used to build the Excel sheet)
    FILE *medians = fopen("part3_2_median.csv", "w");

    if (out == NULL || medians == NULL)
    {
        perror("Opening results CSV");
        return 1;
    }

    if (fprintf(out,"N,n_proc,repetition,sequential_seconds,parallel_seconds\n") < 0 ||
        fprintf(medians,"N,n_proc,repetitions,sequential_median_seconds,parallel_median_seconds\n") < 0)
    {
        perror("Writing CSV header");
        return 1;
    }

    // flushing the headers before any fork, otherwise the children re-write the buffered text on exit
    if (fflush(out) != 0 || fflush(medians) != 0)
    {
        perror("Flushing CSV header");
        return 1;
    }

    // generating the input file once
    if (generate_input() != 0) {
        return 1;
    }

    printf("Part 3 (2): fixed N = %lld\n", FIXED_N);
    printf("Processes tested: %d to %d\n",MIN_PROCESSES, MAX_PROCESSES);
    printf("Repetitions per process count: %d\n", REPETITIONS);

    // increasing the number of processes
    // after 1 we jump to 2 so the even steps still end exactly at MAX_PROCESSES
    for (int n_proc = MIN_PROCESSES; n_proc <= MAX_PROCESSES; n_proc = (n_proc == 1) ? 2 : n_proc + PROCESS_STEP) {

        // confirming correctness (also an untimed warm-up run)
        if (!verify_results(n_proc)) {
            fprintf(stderr,"Verification failed for n_proc=%d\n", n_proc);
            return 1;
        }
        printf("\n========================================\n");
        printf("N = %lld | n_proc = %d\n", FIXED_N, n_proc);
        printf("========================================\n");

        double sequential_times[REPETITIONS];
        double parallel_times[REPETITIONS];

        for (int trial = 0; trial < REPETITIONS; trial++) {

            double sequential_time;
            double parallel_time;

            // alternating
            if (trial % 2 == 0) {
                sequential_time = time_sequential();
                parallel_time = time_parallel(n_proc);
            } else 
            {
                parallel_time = time_parallel(n_proc);
                sequential_time = time_sequential();
            }

            // keeping the times for the median
            sequential_times[trial] = sequential_time;
            parallel_times[trial] = parallel_time;

            /* Print this repetition's results */
            printf("Repetition %2d | Sequential: %.9f s"" | Parallel: %.9f s\n",trial + 1, sequential_time, parallel_time);

            // saving individual measurements to the csv
            if (fprintf(out, "%lld,%d,%d,%.9f,%.9f\n",FIXED_N, n_proc, trial + 1,sequential_time, parallel_time) < 0)
             {
                perror("Writing measurement");
                return 1;
            }
            fflush(out);
        }
        double sequential_median = median(sequential_times, REPETITIONS);
        double parallel_median = median(parallel_times, REPETITIONS);

        printf("----------------------------------------\n");
        printf("Median | Sequential: %.9f s"" | Parallel: %.9f s\n", sequential_median, parallel_median);

        // adding median row
        if (fprintf(medians, "%lld,%d,%d,%.9f,%.9f\n",FIXED_N, n_proc, REPETITIONS, sequential_median, parallel_median) < 0)
         {
            perror("Writing median");
            return 1;
        }
        fflush(medians);
    }
    if (fclose(out) != 0 || fclose(medians) != 0)
    {
        perror("Closing results CSV");
        return 1;
    }
    remove(INPUT_FILE);

    printf("\nTest 2 completed successfully :) \n");
    printf("Results saved to part3_2_raw.csv and part3_2_median.csv!!\n");
    return 0;
}
